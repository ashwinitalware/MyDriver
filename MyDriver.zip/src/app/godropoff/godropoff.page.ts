import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-godropoff',
  templateUrl: './godropoff.page.html',
  styleUrls: ['./godropoff.page.scss'],
})
export class GodropoffPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
