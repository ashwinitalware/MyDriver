import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dropoff',
  templateUrl: './dropoff.page.html',
  styleUrls: ['./dropoff.page.scss'],
})
export class DropoffPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
