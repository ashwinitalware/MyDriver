import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meterreading',
  templateUrl: './meterreading.page.html',
  styleUrls: ['./meterreading.page.scss'],
})
export class MeterreadingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
