import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drop',
  templateUrl: './drop.page.html',
  styleUrls: ['./drop.page.scss'],
})
export class DropPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
