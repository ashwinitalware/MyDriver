import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-companydetails',
  templateUrl: './companydetails.page.html',
  styleUrls: ['./companydetails.page.scss'],
})
export class CompanydetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
